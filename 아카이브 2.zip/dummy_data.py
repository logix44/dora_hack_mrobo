# coding=utf-8
 
 
import matplotlib.pyplot as plt
 
import numpy as np
import pandas as pd

df = pd.read_csv("/Users/juuuun_b/PycharmProjects/test_coding/blockchain/outputtoJi.csv")
df = df[0:50]

print(df)

max_v = max(df['timestamp'])/1000000
min_v = min(df['timestamp'])/1000000

max_d = max(df['value'])/1000000
min_d = min(df['value'])/10

# 데이터 생성
x = np.arange(min_v,max_v)
y = np.arange(min_d,max_d)
z = np.arange(min_v-1000,max_v-1000)

x1=pd.DataFrame(x,columns={"x"})
y1=pd.DataFrame(y,columns={"y"})
z1=pd.DataFrame(z,columns={"z"})

temp_data1=pd.concat([x1,y1,z1],1)
temp_data1["cla"]="서울"

x = np.arange(max_v, min_v)
y = np.arange(max_d, min_d)
z = np.random.rand(19)*1000

x1=pd.DataFrame(x,columns={"x"})
y1=pd.DataFrame(y,columns={"y"})
z1=pd.DataFrame(z,columns={"z"})

temp_data2=pd.concat([x1,y1,z1],1)
temp_data2["cla"]="인천"

data=pd.concat([temp_data1,temp_data2],0)

# make a cla list
group_list=list(data["cla"].drop_duplicates())

fig=plt.figure()

# x축 y축 폭 결정
plt.xlim(1340, 1450)
plt.ylim(580, 675)
plt.ion()

# 색깔 정하기
color=list(["r","b","y","o","g","v"])
color_list=color[0:len(group_list)]

x_list=list((data["x"].drop_duplicates()))


for i in x_list:

    graph_list = list()

    for j in group_list:
        index=group_list.index(j)
        temp_data = data[data["x"] == i]
        temp_data=temp_data[temp_data["cla"]==j]

        graph=plt.scatter(temp_data["x"],temp_data["y"],1,c=color_list[index])
        #graph=plt.scatter(13000,123123,10,c=color_list[index])
        graph_list.append(graph)

    plt.pause(0.1)
    # if i==max(x_list):
    #     break
    # else:
    #     for j in range(0,len(group_list)):
    #         graph_list[j].remove()